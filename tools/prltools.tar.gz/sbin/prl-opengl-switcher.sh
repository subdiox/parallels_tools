#!/bin/bash
#
# Set and unset Parallels OpenGL libraries.
#
# Copyright (c) 1999-2015 Parallels International GmbH.
# All rights reserved.
# http://www.parallels.com

GL_STORAGE_DIR='/var/lib/parallels-tools/GL'
PRL_TOOLS_DIR='/usr/lib/parallels-tools'
PRL_VER_FILE="${PRL_TOOLS_DIR}/version"
DETECT_XSERVER="${PRL_TOOLS_DIR}/installer/detect-xserver.sh"

is_prl_lib() {
	local lib=$1
	if type strings >/dev/null 2>&1; then
		strings "$lib" | grep -q 'Parallels Inc'
		return $?
	fi
	grep -qU 'Parallels Inc' "$lib"
}

install_lib() {
	local src=$1
	local dst=$2
	ln -f "$src" "$dst" 2>/dev/null || cp -aPf "$src" "$dst"
}

store_lib() {
	local lib=$1
	local arch=$2
	local dir=$GL_STORAGE_DIR
	[ -n "$arch" ] && dir="${dir}_${arch}"
	mkdir -p "$dir"  || return 1
	rm -f "${dir}/${lib##*/}"*
	cp -aPf "$lib" "$dir"
}

restore_lib() {
	local lib=$1
	local arch=$2
	local dir=$GL_STORAGE_DIR
	[ -n "$arch" ] && dir="${dir}_${arch}"
	[ -d "$dir" ] || return 1
	rm -f "$lib" && cp -aPf "$dir/${lib##*/}" "$lib"
	# Restore SELinux context
	type restorecon 1>/dev/null 2>&1
	if [ $? -eq 0 ]; then
		restorecon "$lib"
	fi
}

src_prl_bin_path() {
	local arch=$1
	local bins_dir="$PRL_TOOLS_DIR/tools/prltools"
	[ "$arch" = 'x86_64' ] && bins_dir="${bins_dir}.x64"
	if [ ! -d "$bins_dir" ]; then
		mkdir "$bins_dir" &&
			tar xzf "${bins_dir}.tar.gz" -C "$bins_dir" ||
			return $?
	fi
	echo "$bins_dir"
}

tgt_prl_lib_path() {
	local lib_path=$1
	local prl_ver=`< "$PRL_VER_FILE"`
	local max_lib_path=`ls "$lib_path"* | while read f; do
			is_prl_lib "$f" || echo "$f";
		done | tail -n1`
	echo "${max_lib_path}.${prl_ver}"
}

find_installed_prl_libs() {
	local lib_path=$1
	local prl_ver=`< "$PRL_VER_FILE"`
	ls "$lib_path"*"$prl_ver" 2>/dev/null | while read f; do
		[ -f "$f" -a ! -L "$f" ] || continue
		is_prl_lib "$f" && echo "$f"
	done
}

rm_prl_libs() {
	local lib_path=$1
	find_installed_prl_libs "$lib_path" | while read l; do
		rm -f "$l"
	done
}

get_gl_arch() {
	local ld_entry=$1
	echo "$ld_entry" | grep -q '^[[:space:]]*libGL.so.1 \(.*x86-64.*\) =>' &&
		echo 'x86_64' || echo 'i386'
}

get_gl_ld_entries() {
	ldconfig -p | grep '^[[:space:]]*libGL.so.1'
}

get_gl_path() {
	local ld_entry=$1
	echo "$ld_entry" | sed 's/^.*=> \(.*\)$/\1/'
}

enable_gl() {
	local gl_ld_entries=`get_gl_ld_entries`
	if [ -z "$gl_ld_entries" ]; then
		echo 'Warning: libGL.so.1 was not found in the system'
		# If we failed to find libGL on the system we should not install libglx
		# as well.
		return 1
	fi

	IFS=$'\n'
	for ld_entry in $gl_ld_entries; do
		local gl_arch=`get_gl_arch "$ld_entry"`
		local gl_name="libGL.so.1 (${gl_arch})"

		local gl_path=`get_gl_path "$ld_entry"`
		if is_prl_lib "$gl_path"; then
			echo "${gl_name} is Parallels-provided. Skipping."
			continue
		fi

		echo "Saving system-provided ${gl_name}..."
		if ! store_lib "$gl_path" "$gl_arch"; then
			echo "Error: failed to store system-provided ${gl_name}. Aborting."
			return 1
		fi

		local gl_src=`src_prl_bin_path "$gl_arch"`
		if [ -z "$gl_src" ]; then
			echo "Error: not able to set up Parallels-provided ${gl_name}."
			return 1
		fi
		gl_src="${gl_src}/xorg.7.1/usr/lib/libGL.so.1.0.0"

		echo "Installing Parallels-provided ${gl_name}..."
		local gl_dst=`tgt_prl_lib_path "$gl_path"`
		install_lib "$gl_src" "$gl_dst" && ln -sf "$gl_dst" "$gl_path"
		if [ $? -ne 0 ]; then
			echo "Error: failed to write Parallels-provided ${gl_name}"
			return 1
		fi
	done

	return 0
}

disable_gl() {
	local gl_ld_entries=`get_gl_ld_entries`
	if [ -z "$gl_ld_entries" ]; then
		echo 'Warning: libGL.so.1 was not found in the system'
		return 0
	fi

	IFS=$'\n'
	for ld_entry in $gl_ld_entries; do
		local gl_arch=`get_gl_arch "$ld_entry"`
		local gl_name="libGL.so.1 (${gl_arch})"

		local gl_path=`get_gl_path "$ld_entry"`
		if ! is_prl_lib "$gl_path"; then
			echo "${gl_name} is system-provided. Skipping."
			rm_prl_libs "$gl_path"
			continue
		fi

		echo "Restoring system-provided ${gl_name}..."
		if ! restore_lib "$gl_path" "$gl_arch"; then
			echo "Error: failed to restore system-provided ${gl_name}." \
				"Aborting."
			return 1
		fi
		rm_prl_libs "$gl_path"
	done

	return 0
}

get_lib_arch() {
	local lib_path=$1
	if type readelf >/dev/null 2>&1; then
		LANG=C readelf -h "$lib_path" | grep -q 'Class:[[:space:]]*ELF64' &&
			echo 'x86_64' || echo 'i386'
	elif type file >/dev/null 2>&1; then
		LANG=C file -b "$lib_path" | grep -q '^ELF 64-bit LSB' &&
			echo 'x86_64' || echo i386
	else
		uname -m
	fi
}

enable_glx() {
	local xmods_dir=`"$DETECT_XSERVER" -d 2>/dev/null`
	if [ -z "$xmods_dir" ]; then
		echo 'Error: failed to find out Xorg modules directory'
		return 1
	fi
	local glx_path="${xmods_dir}/extensions/libglx.so"
	if [ ! -f "${glx_path}" ]; then
		echo 'Warning: libglx.so module not found in the system. Skipping.'
		return 0
	fi
	if is_prl_lib "$glx_path"; then
		echo 'libglx.so is already Parallels-provided. Skipping.'
		return 0
	fi

	local glx_arch=`get_lib_arch "$glx_path"`
	local prl_bin_path=`src_prl_bin_path "$glx_arch"`
	if [ -z "$prl_bin_path" ]; then
		echo 'Error: not able to set up Parallels-provided libglx.so.'
		return 1
	fi

	local prl_mods_dir=`"$DETECT_XSERVER" -dsrc "$prl_bin_path" 2>/dev/null`
	local src_glx_path="${prl_mods_dir}/usr/lib/libglx.so.1.0.0"
	if [ -z "$prl_mods_dir" -o ! -f "$src_glx_path" ]; then
		echo 'Error: failed to find Parallels-provided GLX Xorg extension.'
		return 1
	fi

	echo 'Saving system-provided libglx.so...'
	if ! store_lib "$glx_path"; then
		echo 'Error: failed to store system-provided libglx.so. Aborting.'
		return 1
	fi

	echo 'Installing Parallels-provided libglx.so...'
	local glx_dst=`tgt_prl_lib_path "$glx_path"`
	install_lib "$src_glx_path" "$glx_dst" && ln -sf "$glx_dst" "$glx_path"
	if [ $? -ne 0 ]; then
		echo 'Error: failed to write Parallels-provided libglx.so'
		return 1
	fi

	return 0
}

disable_glx() {
	local xmods_dir=`"$DETECT_XSERVER" -d 2>/dev/null`
	if [ -z "$xmods_dir" ]; then
		echo 'Error: failed to find out Xorg modules directory'
		return 1
	fi
	local glx_path="${xmods_dir}/extensions/libglx.so"
	if [ ! -f "$glx_path" ]; then
		echo 'Warning: libglx.so module not found in the system. Skipping.'
		return 0
	fi

	if ! is_prl_lib "$glx_path"; then
		echo 'libglx.so is system-provided. Skipping.'
	else
		echo 'Restoring system-provided libglx.so...'
		if ! restore_lib "$glx_path"; then
			echo 'Error: failed to restore system-provided libglx.so. Aborting.'
			return 1
		fi
	fi
	rm_prl_libs "$glx_path"
}

check_prl_tools() {
	if [ ! -r "$PRL_VER_FILE" -o ! -d "${PRL_TOOLS_DIR}/tools" ]; then
		echo 'Fatal: broken Parallels Tools installation.'
		exit 1
	fi
}

cleanup_broken_switches() {
	local prl_bkp_dir='/var/lib/parallels-tools/.backup'
	local prl_list="${prl_bkp_dir}/.prl.libgl.list"
	local run_ldconfig=
	if [ -r "$prl_list" ]; then
		echo 'Found Parallels files from pervious broken installation...'
		cat "$prl_list" | sort -u | while read f; do
			[ -r "$f" ] && is_prl_lib "$f" &&
				echo "Removing '${f}'" && rm -f "$f"
		done
		rm -f "$prl_list"
		run_ldconfig=1
	fi
	local sys_list="${prl_bkp_dir}/.libgl.list"
	local storage_dir="${prl_bkp_dir}/.libgl"
	if [ -r "$sys_list" -a -d "${storage_dir}" ]; then
		echo 'Found stored system parts from previous broken installation...'
		cat "$sys_list" | sort -u | while read f; do
			echo -n " * '${f}'... "
			local src_path="${storage_dir}/${f##*/}"
			if [ -r "$src_path" ] && ! is_prl_lib "$src_path"; then
				# Previous switcher added '.32' suffix to 32-bit libs on 64-bit
				# systems. Need to restore lib without this suffix.
				if [ "${src_path: -3}" = '.32' ]; then
					[ `get_lib_arch "$src_path"` = 'i386' ] &&
						f=${f:: -3}
				fi

				if [ -f "$f" ]; then
					echo 'skipped'
				else
					echo 'restoring'
					mv -f "$src_path" "$f"
				fi
			else
				echo 'missed'
			fi
		done
		rm -f "$sys_list"
		run_ldconfig=1
	fi

	# Special kludge to restore original name of 32-bit libGL on 64-bit system.
	# Previous buggy versions of switchers may leave '.32' suffix in
	# version of library -- need to remove this suffix.
	if [ `uname -m` = 'x86_64' ]; then
		local gl32_path
		local gl64_path
		local gl_ld_entries=`get_gl_ld_entries`
		IFS=$'\n'
		for ld_entry in $gl_ld_entries; do
			local gl_path=`get_gl_path "$ld_entry"`
			case `get_gl_arch "$ld_entry"` in
				'x86_64')
					gl64_path=$gl_path
					;;
				'i386')
					gl32_path=$gl_path
					;;
			esac
		done
		if [ -L "$gl32_path" -a -L "$gl64_path" ]; then
			gl32_path=`readlink -f "$gl32_path"`
			gl64_path=`readlink -f "$gl64_path"`
			if [ "${gl32_path: -3}" = '.32' ] && ! is_prl_lib "$gl32_path"; then
				gl32_path_fixed=${gl32_path%.*}
				if [ "${gl32_path_fixed##*/}" = "${gl64_path##*/}" ]; then
					echo "Removing suffix .32 from path '${gl32_path}'..."
					mv "$gl32_path" "$gl32_path_fixed"
					run_ldconfig=1
				fi
			fi
		fi
	fi

	if [ "$run_ldconfig" = '1' ]; then
		echo 'Running ldconfig...'
		ldconfig
	fi
}

enable_prl_gl() {
	check_prl_tools
	cleanup_broken_switches
	enable_gl && enable_glx
}

disable_prl_gl() {
	check_prl_tools
	cleanup_broken_switches
	disable_glx && disable_gl
}

case "$1" in
	--on)
		enable_prl_gl
		;;

	--off)
		disable_prl_gl
		;;

	*)
		echo "${0##*/} --on|--off"
		exit 2
		;;
esac
exit $?
